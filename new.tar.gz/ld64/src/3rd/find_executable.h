#ifdef __cplusplus
extern "C" {
#endif

char *find_executable(const char *name);

#ifdef __cplusplus
}
#endif
