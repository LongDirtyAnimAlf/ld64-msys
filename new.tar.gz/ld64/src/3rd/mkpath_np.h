#include <sys/stat.h>

#ifdef __cplusplus
extern "C" 
{
#endif

int mkpath_np(const char *path, mode_t omode);

#ifdef __cplusplus
}
#endif
