#ifndef __COMPAT_CORECRYPTO_CCSHA1__
#define __COMPAT_CORECRYPTO_CCSHA1__

#ifdef __cplusplus
extern "C"
{
#endif

const struct ccdigest_info *ccsha1_di(void);

#ifdef __cplusplus
}
#endif

#endif /* __COMPAT_CORECRYPTO_CCSHA1__ */
