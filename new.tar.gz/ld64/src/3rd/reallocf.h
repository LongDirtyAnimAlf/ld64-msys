#ifndef HAVE_REALLOCF

#if defined(__cplusplus)
extern "C" {
#endif

void *reallocf(void *ptr, size_t size);

#if defined(__cplusplus)
}
#endif

#endif
