#ifndef _LIBC_H
#define _LIBC_H

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>

#include <fcntl.h>

#include <sys/stat.h>
#include <sys/types.h>
#include <sys/param.h>

#endif
